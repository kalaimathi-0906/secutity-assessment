import http.client
import os
import subprocess
import sys
import time
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "app"))
import server


class SecurityControlTests(unittest.TestCase):
    def setUp(self):
        server.FAILURES.clear()
        server.SESSIONS.clear()

    def test_password_verification_uses_hash(self):
        self.assertTrue(server.verify_password("DemoPass!2026"))
        self.assertFalse(server.verify_password("wrong-password"))

    def test_password_comparison_is_constant_time_primitive(self):
        import inspect
        self.assertIn("hmac.compare_digest", inspect.getsource(server.verify_password))

    def test_input_length_limits_are_defined(self):
        self.assertEqual(server.MAX_BODY, 4096)
        self.assertEqual(server.RATE_LIMIT, 5)

    def test_response_security_headers_are_defined(self):
        import inspect
        source = inspect.getsource(server.response_headers)
        for header in ("X-Content-Type-Options", "X-Frame-Options", "Referrer-Policy",
                       "Cache-Control", "Content-Security-Policy"):
            self.assertIn(header, source)

    def test_session_cookie_flags_are_defined(self):
        import inspect
        source = inspect.getsource(server.Handler.do_POST)
        self.assertIn("HttpOnly", source)
        self.assertIn("SameSite=Strict", source)
        self.assertIn("Secure", source)

    def test_auth_logs_use_account_reference_not_password(self):
        import inspect
        source = inspect.getsource(server.Handler.do_POST)
        self.assertIn("account_ref=", source)
        self.assertNotIn('log.warning("password=', source)
        self.assertNotIn('log.info("password=', source)

    def test_loopback_binding(self):
        import inspect
        source = inspect.getsource(server)
        self.assertIn('HOST = "127.0.0.1"', source)


if __name__ == "__main__":
    unittest.main(verbosity=2)
