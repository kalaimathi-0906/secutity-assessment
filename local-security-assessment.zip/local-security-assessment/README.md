# Local Application Security Assessment

Beginner-friendly defensive assessment package. It contains a small local authentication application, automated security tests, remediation notes, and a sanitized report.

## Scope and honest status
- Target: the intentionally small demo application in `app/`, running locally only.
- Authorization: the application is included in this repository and is intended for local testing by the repository user.
- Data: synthetic demo account only; no real credentials or personal data.
- The tests exercise the current code in this repository. This is a self-contained lab assessment, **not evidence that another pre-existing application has been tested**.
- Assessment date: 2026-10-29.
- No external systems are in scope.

## Quick start (Python 3.10+; standard library only)
```bash
python -m unittest discover -s tests -v
python app/server.py
```
Then open `http://127.0.0.1:8000/health`. The demo server binds only to loopback.

## Demo credentials
Username: `demo`
Password: `DemoPass!2026`
These are intentionally synthetic lab credentials. Do not reuse them anywhere.

## Included deliverables
- `reports/security-assessment-report.md` — findings, severity, limitations, and summary.
- `scope-and-authorization.md` — scope and rules of engagement.
- `tests/` — automated regression tests.
- `evidence/` — test output and evidence index.
- `remediation/` — remediation mapping and suggested commit messages.
- `reports/retest-results.md` — generated retest status based on test execution.

## Evidence and publication
Before publishing, review the repository for secrets and remove any private information. This package is safe to publish as a demonstration because the credentials and records are synthetic. To create a single proof link, upload this folder to a GitHub repository and set visibility to Public or configure view-only access on your preferred platform. This environment cannot publish to your account or create a GitHub URL on your behalf.
