# Scope, Authorization, and Rules of Engagement

## Objective
Assess a local demo authentication application, document security controls, remediate priority risks, and retest the fixes.

## Authorization statement
The target is the demo application included in this repository. The repository user is authorized to run and test this code locally. No third-party system is authorized or in scope.

## Scope
- Application configuration and HTTP response headers
- Authentication and password verification
- Input validation and request size limits
- In-memory rate limiting
- Session cookie settings and logout
- Dependency footprint
- Security logging and error responses

## Rules of engagement
1. Bind the server to `127.0.0.1` only.
2. Use synthetic demo credentials and data only.
3. Do not scan or test external hosts or third-party services.
4. Do not run destructive, denial-of-service, or credential-stuffing tests.
5. Do not place real credentials, tokens, or personal information in evidence.
6. Keep findings reproducible and distinguish observed behavior from assumptions.
7. Stop if the target changes or is no longer controlled by the repository user.

## Environment and limitations
- Python standard library only; no third-party runtime dependencies.
- The rate limiter and sessions are in-memory and suitable for a small lab, not production multi-worker deployment.
- This is a local educational assessment. It does not replace a professional review, dependency scanner, or production penetration test.
