# Findings Register

This register distinguishes source-code review observations from runtime verification. The automated tests are regression checks for the included demo application, not a comprehensive penetration test.

| ID | Finding / control | Initial risk | Remediation in this version | Retest |
|---|---|---|---|---|
| F-001 | Password verification must not compare plaintext or use ordinary equality | High if implemented incorrectly | Scrypt password hash plus constant-time digest comparison | Pass: correct and incorrect password checks |
| F-002 | Repeated failed login attempts need throttling | High/Medium depending on exposure | Per-account in-memory threshold and 60-second window | Partial: threshold constants/source are checked; full HTTP burst test is not performed |
| F-003 | Session cookies need protective attributes | Medium | HttpOnly, SameSite=Strict, Path; Secure by default | Pass: source-level regression check |
| F-004 | Browser response headers should reduce common risks | Medium/Low | nosniff, frame denial, no-referrer, no-store, restrictive CSP | Pass: source-level regression check |
| F-005 | Logs must not contain credentials | High if secrets are logged | Log event outcome and hashed account reference only | Pass: source-level regression check |
| F-006 | Unbounded request bodies can consume resources | Medium | Reject bodies larger than 4096 bytes | Partial: size limit/source check; runtime boundary cases not covered |
| F-007 | Debug server should not be exposed to a network | High if inadvertently exposed | Bind to loopback address 127.0.0.1 | Pass: source-level regression check |

Severity is contextual. No external scanner or production environment was used. F-002 and F-006 are marked partial because their full runtime behavior has not been exhaustively exercised.
