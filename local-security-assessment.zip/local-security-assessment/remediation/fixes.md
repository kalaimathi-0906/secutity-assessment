# Remediation Notes

## Implemented in the demo
- Password verification uses `hashlib.scrypt` and `hmac.compare_digest`.
- Login fields have type/length/printability validation.
- Request bodies are capped at 4096 bytes.
- Repeated failures are throttled per account in a 60-second in-memory window.
- Session IDs use cryptographically secure random tokens.
- Session cookies set `HttpOnly` and `SameSite=Strict`; `Secure` is enabled by default.
- Responses set basic defensive headers and `Cache-Control: no-store`.
- Logs do not include passwords, tokens, or raw submitted account names.
- The server binds to `127.0.0.1`.

## Production caveats
This is a teaching demo. In-memory rate limiting and sessions do not coordinate across processes and are lost on restart. The static lab account and salt are not suitable for real users. Production use requires a database with unique per-user salts (or a vetted password-hashing library), CSRF protections where applicable, session rotation and expiration, HTTPS, durable distributed throttling, secret management, dependency scanning, and operational monitoring.

## Suggested commit sequence
Use these messages only after creating the corresponding real commits in your Git repository:
1. `security: add input bounds and safe error responses`
2. `security: add password hashing and login throttling`
3. `security: harden session cookies headers and logs`
