"""Loopback-only educational authentication demo with defensive controls."""
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs
import hashlib
import hmac
import json
import logging
import os
import secrets
import time

HOST = "127.0.0.1"
PORT = int(os.environ.get("PORT", "8000"))
MAX_BODY = 4096
RATE_LIMIT = 5
WINDOW_SECONDS = 60
FAILURES = {}  # demo-only in-memory limiter
SESSIONS = {}  # demo-only in-memory sessions

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("local-auth")

# Synthetic lab account. Replace with a proper user database for real applications.
DEMO_USERNAME = "demo"
DEMO_PASSWORD = "DemoPass!2026"
SALT = b"local-assessment-demo-salt"
PASSWORD_HASH = hashlib.scrypt(DEMO_PASSWORD.encode(), salt=SALT, n=2**14, r=8, p=1)


def verify_password(password: str) -> bool:
    candidate = hashlib.scrypt(password.encode(), salt=SALT, n=2**14, r=8, p=1)
    return hmac.compare_digest(candidate, PASSWORD_HASH)


def response_headers(handler):
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("X-Content-Type-Options", "nosniff")
    handler.send_header("X-Frame-Options", "DENY")
    handler.send_header("Referrer-Policy", "no-referrer")
    handler.send_header("Cache-Control", "no-store")
    handler.send_header("Content-Security-Policy", "default-src 'none'; frame-ancestors 'none'")
    # Secure is enabled by default; set COOKIE_SECURE=0 only for local HTTP testing.
    secure = os.environ.get("COOKIE_SECURE", "1") != "0"
    handler._cookie_secure = secure


class Handler(BaseHTTPRequestHandler):
    server_version = "LocalAssessment"
    sys_version = ""

    def log_message(self, fmt, *args):
        # Do not log request bodies, credentials, cookies, or query strings.
        log.info("http_request client=%s message=%s", self.client_address[0], fmt % args)

    def send_json(self, status, payload, extra_headers=None):
        self.send_response(status)
        response_headers(self)
        if extra_headers:
            for k, v in extra_headers.items():
                self.send_header(k, v)
        self.end_headers()
        self.wfile.write(json.dumps(payload).encode())

    def read_form(self):
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            return None
        if length < 0 or length > MAX_BODY:
            return None
        raw = self.rfile.read(length)
        try:
            return parse_qs(raw.decode("utf-8"), strict_parsing=True)
        except (UnicodeDecodeError, ValueError):
            return None

    def do_GET(self):
        if self.path == "/health":
            return self.send_json(200, {"status": "ok"})
        if self.path == "/":
            return self.send_json(200, {"service": "local-auth-demo", "routes": ["/health", "/login", "/logout"]})
        return self.send_json(404, {"error": "not_found"})

    def do_POST(self):
        if self.path not in ("/login", "/logout"):
            return self.send_json(404, {"error": "not_found"})
        form = self.read_form()
        if form is None:
            return self.send_json(400, {"error": "invalid_request"})
        if self.path == "/logout":
            token = self.headers.get("Cookie", "")
            session_token = ""
            for part in token.split(";"):
                if part.strip().startswith("session="):
                    session_token = part.strip().split("=", 1)[1]
            SESSIONS.pop(session_token, None)
            secure = "; Secure" if os.environ.get("COOKIE_SECURE", "1") != "0" else ""
            return self.send_json(200, {"status": "logged_out"}, {"Set-Cookie": f"session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0{secure}"})

        username = form.get("username", [""])[0]
        password = form.get("password", [""])[0]
        if (not username or not password or len(username) > 64 or len(password) > 256
                or not username.isprintable() or not password.isprintable()):
            return self.send_json(400, {"error": "invalid_input"})

        now = time.time()
        recent = [t for t in FAILURES.get(username, []) if now - t < WINDOW_SECONDS]
        FAILURES[username] = recent
        if len(recent) >= RATE_LIMIT:
            log.warning("auth_event outcome=rate_limited account_ref=%s", hashlib.sha256(username.encode()).hexdigest()[:12])
            return self.send_json(429, {"error": "try_again_later"})

        if username != DEMO_USERNAME or not verify_password(password):
            recent.append(now)
            FAILURES[username] = recent
            # Use a generic response; never log submitted username/password.
            log.warning("auth_event outcome=failure account_ref=%s", hashlib.sha256(username.encode()).hexdigest()[:12])
            return self.send_json(401, {"error": "invalid_credentials"})

        FAILURES.pop(username, None)
        session = secrets.token_urlsafe(32)
        SESSIONS[session] = {"account": DEMO_USERNAME, "created": now}
        secure = "; Secure" if os.environ.get("COOKIE_SECURE", "1") != "0" else ""
        log.info("auth_event outcome=success account_ref=%s", hashlib.sha256(username.encode()).hexdigest()[:12])
        return self.send_json(200, {"status": "authenticated"}, {"Set-Cookie": f"session={session}; HttpOnly; SameSite=Strict; Path=/{secure}"})


if __name__ == "__main__":
    print(f"Starting local-only demo at http://{HOST}:{PORT}")
    HTTPServer((HOST, PORT), Handler).serve_forever()
